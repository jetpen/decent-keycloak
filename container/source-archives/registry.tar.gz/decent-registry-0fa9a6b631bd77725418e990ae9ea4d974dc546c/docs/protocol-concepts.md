# Protocol concepts and configuration vocabulary

This document covers the core protocol concepts and how they map to the CLI flags and YAML config fields in this repo.

This document is standalone: it defines the core protocol concepts, data schemas, and how they map to CLI flags and YAML configuration in this repo.

---

## 1) Transport and lookup: libp2p Kad-DHT (Kademlia)

`decent-registry` uses **libp2p Python Kad-DHT** in server mode.

- A node runs `decent-registry node` which starts:
  - a libp2p host bound to `--host` / `--port` (TCP enabled)
  - a Kad-DHT instance
  - (optional) a local LMDB durable datastore for fallback caching

When storing or retrieving records, the DHT key is namespaced to avoid collisions:

- provider records (payload = provider schema)
  - DHT key: `/decent-registry/provider/{object_hash}`
- identity records (payload = empty; identity data is taken from `record_fields`)
  - DHT key: `/decent-registry/identity/{object_key}`

In code: `_kad_key(object_hash, kind='provider'|'identity')` returns `f"/decent-registry/{kind}/{object_hash}"`.

---

## 2) Bootstrap: how nodes discover each other

**Bootstrap** is the initial connectivity step for routing in the DHT.

Implementation details:
- CLI/YAML `bootstrap` values must be **identify-style multiaddrs** that include `/p2p/<peerid>`.
- `Libp2pKadDHT.bootstrap(remote_tcp_multiaddr)` rejects destinations missing `/p2p/`.
- It then parses the multiaddr with `info_from_p2p_addr(Multiaddr(...))` and calls `host.connect(peer_info)`.

CLI config / flags:
- `decent-registry node` accepts repeated `--bootstrap` values
- `decent-registry put ...` and `decent-registry get ...` accept the same `--bootstrap` list

Note: in this repo, the command line `--bootstrap` values are passed as the *same list* to all client commands, and clients bootstrap their host before performing `put`/`get`.

---

## 3) Multiaddr endpoints (provider record payload)

Only **provider records** include a list of endpoints. The endpoints live in the **provider payload** and are not part of the signed identity.

Validation and signing constraints (from `provider_schema.py`):
- each endpoint must be a string starting with `/` (multiaddr syntax)
- max 32 endpoints
- each endpoint string must be <= 256 bytes (UTF-8)
- endpoints are **lexicographically sorted** before signing

How sorting is enforced:
- `build_provider_payload_dict(...)` calls `normalize_sorted_endpoints(endpoints)`
  - validates each endpoint
  - sorts lexicographically (`sorted(eps)`) before returning the payload dict
- `decode_provider_payload_dict(...)` calls `_require_endpoints_sorted(endpoints)`
  - rejects payloads where `endpoints != sorted(endpoints)`

CLI-to-payload mapping:
- `decent-registry put provider --endpoint ...`:
  - `--endpoint` is repeatable and may be comma-separated
  - `_parse_endpoints()` splits on commas and strips whitespace
  - `RegistryService.put_provider()` passes the resulting list to `build_provider_payload_dict()` which sorts before signing

---

## 4) SHA-256 lookup keys: `object_key` and `object_hash`

The protocol uses SHA-256 digests to derive DHT lookup keys.

### Identity lookup key

For an **identity record**, the CLI derives the DHT key from `--owner-name`:

- `owner_name_bytes = bytes.fromhex(owner_name_hex)`
- `object_key_hex = sha256(owner_name_bytes).hexdigest()`

This derivation appears in `RegistryService._derive_identity_object_hash_from_owner_name_hex()` and is used by:
- `RegistryService.put_identity(...)`
- `RegistryService.get_identity(...)`

So:
- `decent-registry put identity --owner-name <hex>` stores under `/decent-registry/identity/{sha256(owner_name_bytes).hex}`
- `decent-registry get identity --owner-name <hex>` queries the same key

### Provider lookup key

For a **provider record**, the DHT key is supplied explicitly as `--object-hash`.

In this repo:
- the DHT key bytes for provider are `bytes.fromhex(object_hash)` (must be 64 hex chars)
- the provider payload also includes `object_hash` as a signed field

So `--object-hash` must be a 64-hex string.

---

## 5) Record types: identity vs provider

This repo supports two record types:

### Identity record

Stored as a SignedUpdate where:
- `record_fields[1]` = `owner_name_bytes` (bytes)
- `record_fields[2]` = `owner_public_key` bytes (Ed25519 public key bytes)
- `payload` is `{}`

On get, the client prints:
- `object_key` (the DHT key queried)
- `owner_name` (hex of `record_fields[1]`)
- `owner_public_key` (hex of `record_fields[2]`)
- `seq`

Key derivation and owner binding:
- DHT identity key derives from `owner_name_bytes`
- signature verification derives the identity record key from `owner_name_bytes`
- overwrite authorization binds identity to the `owner_public_key` bytes

### Provider record

Stored as a SignedUpdate where:
- `record_fields[1]` = `owner_public_key` bytes (Ed25519 public key bytes)
- `payload` for an active Provider Record v3 includes:
  - `1`: `alg` (currently `Ed25519`)
  - `2`: `version` (`3`)
  - `3`: `object_hash` (64-hex string)
  - `4`: `provider_urls` (list of 1–32 unique absolute URIs, sorted; each at most 2048 UTF-8 bytes)
  - `5`: `endpoints` (list<string>, sorted; multiaddrs remain separate from provider URI locators)

Provider URI locators may use any syntactically valid URI scheme. The Registry
validates and returns them but does not fetch them or implement scheme-specific
protocol handlers. Clients are responsible for supported schemes and verifying
retrieved bytes against `object_hash`. Active v1 payloads are unsupported; old
records must be republished as v3. The v2 withdrawal tombstone remains unchanged.

A Provider withdrawal is a distinct v2 tombstone payload with fields `1: alg`,
`2: 2`, `3: object_hash`, `4: "withdrawn"`, and optional `5:
replacement_object_hash`. It has no provider URLs or endpoints.

  #### Provider withdrawal payload v2

  An owner-authorized withdrawal is a Provider payload v2 tombstone at the same
  `/decent-registry/provider/{object_hash}` key. The active v3 payload and its
  SignedUpdate signature purpose are unchanged. The canonical tombstone payload
  contains exactly these fields (key 5 is optional):

  ```text
  {
    1: alg,
    2: 2,
    3: object_hash,
    4: "withdrawn",
    5: replacement_object_hash,  # optional; omit when absent
  }
  ```

  It contains no provider URLs or endpoints. Hashes are 64 hexadecimal
  characters, and a replacement cannot point to the withdrawn hash. The
  replacement is an owner-authored pointer; the Registry does not resolve it or
  require that it be active or owned by the same key.

  A withdrawal must be a strictly higher-Seq state than a valid active head.
  Legacy records require the bound Owner Public Key. Multisignature records
  require the current threshold and exact predecessor-state hash. A higher-Seq
  active v3 Provider Record can reactivate the key, after which it may be
  withdrawn again. Repeated withdrawals fail with `ProviderAlreadyWithdrawn`.
  When the Registry can validate a tombstone, `get provider` returns JSON with
  `status: "withdrawn"`, `object_key`, `seq`, optional
  `replacement_object_key`, and multisignature authorization metadata where
  applicable. Missing records remain `not found`; an unvalidated/conflicting
  head is not an explicit withdrawn result.

  Withdrawal stops future discovery/use through that Provider Record where the
  tombstone is observed. It does not delete an external Storage Object, erase
  Registry history, replicas, caches, or copies already obtained, guarantee
  immediate/global propagation, or provide cross-node compare-and-swap. No
  pre-MVP migration or mixed-version deployment guarantee is made.

On get, the client prints:
- `object_key` (the queried `object_hash` string)
- `provider_urls` (validated, sorted URI locator list)
- `endpoints` (validated/sorted multiaddrs)

---

## 6) Keys and signatures: Ed25519 + canonical CBOR

### Private/public key material

- CLI keygen produces an Ed25519 private key in **PKCS#8 PEM** format.
- The CLI config field `crypto.owner_privkey_pem_path` supplies the PEM path.

The key content is never printed or logged; it is loaded via `load_ed25519_keypair_from_privkey_pem_path()`.

### SignedUpdate digest input

The signature binds a deterministic, canonical encoding.

The signature digest input is:
- `SignedUpdate = { 1: record_fields, 2: payload, 3: seq }`
- encoded with canonical CBOR
- then signed as Ed25519 over `sha256(canonical_signed_update_bytes)`

In code:
- `encode_signed_update(record_fields, payload, seq)` produces canonical CBOR bytes
- `make_signed_update_signature(...)` computes `digest_msg = sha256(signed_update_bytes_canonical)` and calls `owner_private_key.sign(digest_msg)`

### SignedEnvelope

The stored DHT value is a canonical CBOR envelope:

- `SignedEnvelope = { 1: signed_update_bytes, 2: signature }`

`encode_signed_envelope(...)` uses `cbor2.dumps(..., canonical=True)`.

Verification requires canonical CBOR:
- SignedEnvelope must be canonical (`is_canonical_cbor(envelope_cbor)`)
- SignedUpdate bytes inside the envelope must also be canonical (`decode_canonical_signed_update`)

### 6.1) Version-1 multisignature wire schema

This section documents the versioned wire format and codec validation from
issue #92, state-transition validation from issue #93, and the implemented CLI
and Registry integration from issues #95 and #96. The complete workflow is
summarized in [Multisignature Records and Migration](multisignature-records.md).

The legacy envelope remains exactly:

```text
SignedEnvelope = { 1: signed_update_bytes, 2: signature }
```

The explicit-signer version-1 envelope is a separate shape and is never
interpreted as a legacy envelope:

```text
SignedEnvelopeV1 = {
  1: 1,                         # envelope version
  2: signed_update_bytes,
  3: [ { 1: signer_id, 2: signature }, ... ]
}
```

The versioned envelope carries one canonical SignedUpdate. Its shared
authorization map is SignedUpdate key `4`:

```text
SignedUpdate = {
  1: record_fields,
  2: payload,
  3: seq,
  4: authorization,
}

authorization = {
  1: 1,                         # explicit independent Ed25519 scheme
  2: record_kind,               # 1 identity, 2 provider
  3: operation,                 # 1 genesis, 2 ordinary, 3 replace, 4 upgrade
  4: epoch,
  5: threshold,
  6: [ { 1: signer_id, 2: public_key }, ... ],
  7: predecessor_state_hash,   # exactly 32 bytes
}
```

Signer identifiers are UTF-8 text. Public keys are 32-byte Ed25519 keys and
signatures are 64-byte Ed25519 signatures. The signer set and proof collection
are sorted by UTF-8 signer identifier before encoding; decoders reject
non-canonical ordering, duplicate identifiers, duplicate public keys, malformed
keys, invalid thresholds, unsupported envelope versions, unsupported schemes,
and malformed maps. The authorization `record_kind` must match the Identity or
Provider SignedUpdate structure. Proof membership, threshold authorization,
epoch transitions, predecessor-state checks, and state installation belong to
the authorization validator rather than this codec.

Legacy `decode_signed_envelope` continues to decode only `{1,2}`. The
multisignature decoder requires `{1,2,3}` and version `1`, so an old client
cannot treat one multisignature proof as a legacy signature.

### 6.2) Multisignature state-transition validation

The accepted-state hash is `sha256(canonical SignedUpdate bytes)`. A candidate
transition must bind its authorization predecessor field to that hash.

- `genesis` requires a zero predecessor, `epoch = 1`, and a complete 2-of-3 set.
- `ordinary update` requires the current epoch and unchanged signer set and
  threshold, with a strictly higher `seq`.
- `replace signers` requires a complete new 2-of-3 set, a higher epoch and
  `seq`, and proofs from the current set; the new set cannot authorize its own
  installation.
- `upgrade` requires the current legacy owner signature, the same lookup key
  and owner binding, a strictly higher `seq`, `epoch = 1`, and a complete 2-of-3
  set.

All proof signatures must be distinct, valid Ed25519 signatures from the
required current signer set. This module provides pure transition validation;
`RecordValidator`, `RegistryService`, and `Libp2pKadDHT` apply that validation to
multisignature `put`/`get` operations and durable accepted-state installation.

### 6.3) Local Multisignature Bundle workflow

`decent_registry.multisig_bundle` provides local-only workflow operations:

1. `draft_identity_bundle` or `draft_provider_bundle` creates canonical
   SignedUpdate bytes and an empty proof collection. Provider bundle drafts
   accept 1–32 `provider_urls` and emit active payload v3.
2. `sign_bundle` accepts exactly one caller-local Ed25519 private key and
   returns a detached proof. The private key is not stored in the bundle.
3. `merge_proof` verifies exact SignedUpdate binding, signer membership,
   duplicate rejection, and the Ed25519 signature before adding a proof.
4. `finalize_bundle` rejects a partial bundle and returns a versioned
   SignedEnvelope only after the threshold of distinct valid proofs is met.

Bundles may be serialized as canonical versioned envelope-shaped CBOR while
partial. They are local signing artifacts, not accepted Registry state. The
CLI commands are `bundle draft`, `bundle sign`, `bundle merge`, and
`bundle finalize`. Registry submission uses `put identity` or `put provider`
with `--finalized-envelope`; `get` validates and exposes authorization
metadata. See [Multisignature Records and Migration](multisignature-records.md)
for runnable workflows and the compatibility matrix.

---

## 7) Overwrite rules: seq monotonicity + owner binding

For a fixed DHT key, later updates are accepted only if they satisfy:

1) **Canonical SignedUpdate** decoding
2) **Ed25519 signature validity**
3) **`seq` strictly increases** for that record key
4) **Owner binding / collision prevention**

Enforcement details in `verification.py`:
- prev state is extracted from the existing envelope:
  - provider prev owner pk is from `existing_signed_update[1][1]`
  - identity prev owner pk is from `existing_signed_update[1][2]`
  - prev seq is `existing_signed_update[3]`
- checks:
  - if `seq <= prev.seq`: reject (`seq must be strictly increasing`)
  - For legacy updates, if `owner_public_key != prev.owner_public_key`: reject (`owner collision`).
- A version-1 Identity owner-key change is accepted only as a validated operation-5 Owner-Key Rotation, after its complete predecessor history and operation-specific proofs are verified. All other Identity operations preserve the Owner Public Key.

Consequence:
- The first accepted update for a key establishes its Owner Public Key; only a validated operation-5 Identity transition may change that binding.

Key revocation is a separate future design noted in closed issue #15 (allow object rewrites signed with an identity key that has been revoked).
- Legacy overwrites must retain the same Owner Public Key. See [Multisignature Records and Migration](multisignature-records.md) for the operation-5 Identity exception.

---

## 8) Configuration vocabulary and CLI flag mapping

All CLI commands accept a YAML config and a subset of CLI overrides.

### Server YAML (`~/.decent/registry.yaml`)

Module: `src/decent_registry/config.py`.

Fields:
- `network.host` (string, default `127.0.0.1`)
- `network.port` (int, default `None`; required for `node`)
- `network.bootstrap` (list<string>, default `[]`)
- `datastore.path` (string; default `~/.decent/registry`)
- `datastore.mapsize_bytes` (int|null; optional)
- `logging.verbosity` (int; 0=WARNING, 1=INFO, >=2=DEBUG)

`decent-registry node` resolves requiredness after merging config + CLI overrides.

CLI flags for server:
- `--config <path>` (defaults to `~/.decent/registry.yaml`)
- `--host <ip>`
- `--port <int>` (required after resolution)
- `--bootstrap <multiaddr>` (repeatable; list)
- `--datastore-path <path>` (LMDB path)
- `--mapsize <int>`
- `--run-seconds <float>`
- `-v/--verbose` (count)

### Client YAML (`~/.decent/registry_cli.yaml`)

Fields:
- `network.host` (string, default `127.0.0.1`)
- `network.port` (int, required for client commands)
- `network.bootstrap` (list<string>, default `[]`)
- `datastore.path` (string; default `.scratch/decent-registry.lmdb`)
- `datastore.mapsize_bytes` (int|null; optional)
- `logging.verbosity` (int; 0=WARNING, 1=INFO, >=2=DEBUG)
- `crypto.owner_privkey_pem_path` (string|null; required for `put ...`)

CLI config override semantics:
- CLI flags overwrite corresponding YAML fields after loading.
- `--owner-privkey` (for `put provider` / `put identity`) overwrites `crypto.owner_privkey_pem_path`.

Client CLI flags common to `put`/`get`:
- `--config <path>` (defaults to `~/.decent/registry_cli.yaml`)
- `--host <ip>`
- `--port <int>`
- `--bootstrap <multiaddr>` (repeatable)
- `--datastore-path <path>`
- `--mapsize <int>`
- `-v/--verbose` (count)

---

## 9) How `decent-registry` exposes protocol concepts via CLI

### Node/server

- `decent-registry node --host <ip> --port <node_port> [--bootstrap <identify-maddr>]`
- Prints node peer id and listen multiaddr when `-v/--verbose` is enabled (via logger).

### `put identity`

- Inputs:
  - `--owner-name <hex bytes>`
  - `--owner-privkey <pem path>`
  - `--seq <monotonic int>`
- Key derivation:
  - `object_key = sha256(owner_name_bytes)`
- Stored value:
  - SignedEnvelope over canonical CBOR SignedUpdate

### `get identity`

- Inputs:
  - `--owner-name <hex bytes>`
- Output JSON:
  - includes `seq`, `owner_name`, `owner_public_key`

### `put provider`

- Inputs:
  - `--object-hash <64-hex>`
  - `--provider-url <absolute-uri>` (repeatable; 1–32 distinct locators)
  - `--owner-privkey <pem path>`
  - `--seq <monotonic int>`
  - `--endpoint <multiaddr>` (repeatable/comma-separated)
- The active v3 payload stores sorted `provider_urls` at field `4` and the unchanged sorted multiaddr `endpoints` at field `5`. Clients select supported schemes; the Registry does not fetch locators.
- `https:foo` is valid as an absolute generic URI even though a consumer may not handle it as an HTTP URL.
- URI validation accepts RFC 3986 registered-name syntax and is not a DNS hostname policy.
- payload list requirements:
  - each value is a valid absolute URI with a scheme and no whitespace
  - 1–32 distinct locators, each <=2048 UTF-8 bytes
  - lexicographically sorted before signing
- endpoints requirements:
  - max 32 endpoints, each <=256 bytes
  - endpoints are sorted lexicographically before signing

### `get provider`

- Inputs:
  - `--object-hash <64-hex>`
- Output JSON:
  - `provider_urls` and sorted `endpoints`
