# Multisignature Records and Migration

This document describes the implemented version-1 multisignature workflow for Identity Records and Provider Records. It covers the canonical wire format, state transitions, local Multisignature Bundle circulation, finalized SignedEnvelope submission, compatibility with legacy single-key records, and security boundaries.

The implementation is code-backed by `src/decent_registry/encoding.py`, `signed_envelope.py`, `verification.py`, `multisig_bundle.py`, `record_validator.py`, `registry_service.py`, and `dht/libp2p_dht.py`. The CLI commands are exercised by `tests/test_cli_multisig.py`.

## 1. Claim classes and scope

The following behavior is **implemented and code-backed**:

- canonical version-1 multisignature SignedUpdate and SignedEnvelope codecs;
- Identity Record and Provider Record drafts;
- detached local signing and proof merging;
- threshold finalization, including explicit legacy upgrade;
- finalized-envelope `put` for both record families;
- multisignature `get` output with authorization metadata;
- owner-authorized Provider Record withdrawal as a signed v2 tombstone at the existing Object Hash key, selected-head lookup outcomes, and optional replacement pointers;
- legacy single-key compatibility before upgrade and rejection of legacy writes after upgrade;
- signer replacement, ordinary updates, Identity owner-key rotation (operation 5), strict `Seq` ordering, predecessor-state binding, and lookup-key binding.
- replay of locally retained Identity predecessor history before accepting or resolving operation-5 state; missing or incomplete provenance fails closed.

The following claim classes are not current Registry behavior:

**Claim Class: Documented or researched but unimplemented.**

- Recovery policies separate from ordinary threshold authorization.
- FROST, DKG, resharing, and threshold-signature aggregation.

**Claim Class: Proposed design.**

- HTTP gateways, browser integrations, Identity Graphs, and Companion Service protocols.

**Claim Class: Long-term vision.**

- Deployment-level availability, privacy, governance, and application-service guarantees are Ecosystem Goals, not current Registry guarantees.

This document does not change the legacy wire format. It documents the interfaces already present in the repository.

## 2. Wire format

### 2.1 Legacy SignedEnvelope

The legacy envelope remains the two-key canonical CBOR map:

```text
SignedEnvelope = {
  1: signed_update_bytes,
  2: signature,
}
```

Its embedded legacy SignedUpdate is:

```text
SignedUpdate = {
  1: record_fields,
  2: payload,
  3: seq,
}
```

The legacy envelope codec accepts only this outer shape and rejects a nested multisignature SignedUpdate. The legacy validation path then validates the legacy SignedUpdate, record family, signature, lookup key, Owner Binding, and `Seq`.

### 2.2 Version-1 multisignature SignedEnvelope

The versioned envelope is a different canonical CBOR map:

```text
SignedEnvelopeV1 = {
  1: 1,                         # envelope version
  2: signed_update_bytes,
  3: [ { 1: signer_id, 2: signature }, ... ],
}
```

It carries one canonical multisignature SignedUpdate:

```text
SignedUpdate = {
  1: record_fields,
  2: payload,
  3: seq,
  4: authorization,
}
```

The authorization map is:

```text
authorization = {
  1: 1,                         # explicit independent Ed25519 scheme
  2: record_kind,               # 1 = Identity Record, 2 = Provider Record
  3: operation,                 # 1 genesis, 2 ordinary update,
                                # 3 replace signers, 4 upgrade,
                                # 5 owner-key rotation
  4: epoch,
  5: threshold,
  6: [ { 1: signer_id, 2: public_key }, ... ],
  7: predecessor_state_hash,   # exactly 32 bytes
}
```

Signer identifiers in Signer Sets are non-empty UTF-8 text. Public keys are 32-byte Ed25519 public keys. Proof signatures are 64-byte Ed25519 signatures. Proofs are ordered by the UTF-8 bytes of `signer_id`; operation 5's single legacy-owner proof uses `signer_id: null`, whose canonical sort key is empty bytes. Null is accepted only for a verified legacy Identity predecessor under operation 5.

The codecs reject non-canonical CBOR, wrong map shapes, unsupported envelope versions, unsupported authorization schemes, duplicate signer identifiers, duplicate public keys, malformed keys, malformed signatures, invalid thresholds, and non-canonical proof ordering. The transition validator additionally checks proof membership, signatures, thresholds, `Seq`, epochs, predecessor state, record-key binding, wrong record kinds, and operation-specific rules.

The canonical bytes of the SignedUpdate are the bytes signed by every signer. The state hash is `sha256(canonical_signed_update_bytes)`. A proof is valid only for that exact byte string; reconstructing an equivalent but differently encoded map is not sufficient.

### 2.3 Record-specific fields

Identity Record multisignature updates retain the existing record shape:

```text
record_fields = {
  1: owner_name_bytes,
  2: owner_public_key,
}
payload = {}
```

The Object Key is `sha256(owner_name_bytes)`. The Owner Public Key remains bound across ordinary updates and is preserved during an explicit upgrade.

```text
record_fields = {
  1: owner_public_key,
}
```

### Provider Record (active v3)

The Object Key is the Object Hash. Active payload fields are `1: alg`, `2: 3`,
`3: object_hash`, `4: provider_urls` (1–32 unique, sorted absolute URIs, each
at most 2048 UTF-8 bytes), and `5: endpoints` (the unchanged sorted multiaddr
list). Provider locators accept protocol-agnostic URI schemes; the Registry
does not fetch them or implement scheme handlers. Consumers select supported
schemes and verify retrieved bytes against `object_hash`. Active v1 payloads
are unsupported and must be republished as v3. The v2 withdrawal tombstone
below is unchanged.

#### Provider withdrawal and v2 tombstone

A Provider withdrawal is an ordinary update transition whose signed payload has
this v2 shape at the existing Object Hash key:

```text
payload = {
  1: alg,
  2: 2,
  3: object_hash,
  4: "withdrawn",
  5: replacement_object_hash,  # optional
}
```

The tombstone has no URL or endpoints. Legacy records use their bound Owner
Public Key; multisignature records require the current threshold and exact
predecessor state hash. A higher-Seq active v3 state can reactivate the key.
Replacement Object Hashes are validated for format and self-reference only;
the Registry does not require the target to exist or share its owner.

Draft a multisignature withdrawal with
`decent-registry bundle draft provider --withdrawal`, the existing active
Signer Set, a higher Seq, and the exact predecessor state hash. Then use the
regular sign/merge/finalize steps. Submit the finalized envelope through
`decent-registry withdraw provider --finalized-envelope <path>`. Legacy mode
uses `withdraw provider --owner-privkey <path> --seq <higher>`. The Registry
fails closed unless it can establish a valid active predecessor; a repeated
withdrawal is a typed failure. A higher-Seq active v3 publication can reactivate
that key, and then a later withdrawal is allowed.

When a tombstone is observed and validated, `get provider` returns
`status: "withdrawn"`, `object_key`, `seq`, optional
`replacement_object_key`, and multisignature authorization metadata where
applicable. Missing records remain missing, not withdrawn. Withdrawal does not
delete the external Storage Object or erase history, replicas, caches, or
copies already obtained. It does not promise immediate/global propagation or
cross-node compare-and-swap. Pre-MVP migration and mixed-version deployment are
not guaranteed.

## 3. State transitions

Every accepted multisignature state is bound to one record lookup key.

| Operation | Authorization requirement | State rule |
| --- | --- | --- |
| `genesis` | Complete 2-of-3 Signer Set; `epoch = 1`; zero predecessor | No prior legacy or multisignature state may exist. |
| `ordinary-update` | Threshold proofs from the current Signer Set | `Seq` strictly increases; epoch, threshold, and Signer Set remain unchanged; predecessor binds the current state hash. |
| `replace-signers` | Threshold proofs from the current Signer Set | `Seq` strictly increases; epoch increases; a new complete 2-of-3 Signer Set is installed; the new set cannot authorize its own installation. |
| `upgrade` | Exactly one valid proof from the legacy Owner Public Key | The legacy state must exist; lookup key, record kind, Owner Binding, and predecessor hash must match; `Seq` strictly increases; `epoch = 1`; the new state contains a complete 2-of-3 Signer Set. |
| `owner-key-rotation` (Identity only) | Exactly one predecessor-owner proof for a legacy predecessor, or the predecessor version-1 threshold | The Owner Public Key must change; `Seq = predecessor.seq + 1`; raw Owner Name bytes, record kind, Object Key, and predecessor hash match. A legacy rotation installs epoch 1, threshold 2, and three distinct successor signers including the successor Owner Public Key. A version-1 rotation preserves its Signer Set, threshold, and epoch. |

A finalized ordinary or replacement update requires at least `threshold` distinct valid proofs. An upgrade is intentionally different: it requires exactly one proof from the legacy owner, not the new threshold. A legacy operation-5 rotation also requires exactly one proof from the legacy Owner Public Key, but its `signer_id` is null and the successor Owner Public Key must belong to the new 2-of-3 set. A version-1 operation-5 rotation is authorized by the predecessor Signer Set and does not require the successor Owner Public Key to be in that unchanged set. Every operation other than operation 5 preserves Owner Public Key. After a multisignature state is accepted, a legacy single-key write is rejected for that record key.

Operation-5 validation replays the complete locally retained predecessor envelope chain from its signed legacy anchor. The chain is written atomically with the accepted Identity state in LMDB. A standalone non-genesis Identity envelope, missing history, a history that does not end at the current envelope, or any invalid ancestor is rejected; `get` returns no Identity Record when provenance cannot be verified. This history is local accepted-state metadata, not a change to the DHT envelope format.

Registry operation-5 validation, accepted-state integration, and independent remote read-back are implemented. `RegistryService.confirm_identity_owner_key_rotation(owner_name_hex=..., expected_envelope_cbor=...)` returns an `IdentityRecordResult` only when a fresh client issues direct GET_VALUE requests to configured bootstrap peers and returns bytes exactly equal to the expected finalized envelope, then the Registry replays its complete accepted predecessor chain from a signed anchor. The read bypasses `KadDHT.get_value()` and its entry-repair behavior, does not cache or propagate the returned value, and returns raw bytes for the confirmation method to validate. The fresh client has no durable store and does not use the writer's DHT value store or write result. It is bootstrapped to peers previously supplied through `Libp2pKadDHT.bootstrap(...)`; without configured peers or a successful exact remote response, the method returns `None`. This single-peer read proves only that a remote DHT peer returned the exact value at read time; it does not prove quorum replication, global currentness, or network-wide durability. The method returns validated public record data, not a wallet `RotationConfirmation`. Wallet private-key handling, consent, dispatch latching, ambiguous-outcome resolution, publication finalization, and successor-key promotion are owned by the separate Wallet repository and are not implemented here. Wallet issue #18 remains open; Registry acceptance/read-back alone is not wallet confirmation.

`RegistryService.get_identity_envelope(...)` returns exact current envelope bytes after normal accepted-state selection and Registry validation. If a DHT value extends this node's retained accepted history, it validates the complete chain before caching the new head. `RegistryService.get_identity_envelope_by_hash(...)` searches this node's retained accepted Identity history using the SHA-256 hash of canonical SignedUpdate bytes. It is not a DHT-wide history lookup. Both methods return `None` when no locally validated matching envelope is available; callers that require a predecessor must fail closed when it is unavailable.

`Libp2pKadDHT.read_remote_identity_envelope_by_hash(...)` requests one predecessor directly from configured Registry peers. Its compact binary GET_VALUE key is the `/decent-registry/history/` prefix followed by the 32-byte Identity object key and 32-byte SignedUpdate state hash; the encoding stays within libp2p's 128-byte key limit. A peer serves the envelope from its locally validated, durable LMDB history. The response is raw and untrusted until the client validates the complete chain. Remote traversal is bounded to 256 envelopes, 4 MiB of envelope data, or 15 seconds total; exceeding a bound is treated as unavailable history, never as permission to accept an unverified head. The query bypasses Kademlia repair and local cache, and only configured peers are queried, so this is not an archival or network-wide availability guarantee.

`RegistryService.put_identity_envelope_if_current(...)` requires a non-null 32-byte `expected_state_hash` naming an existing state. It rejects `None`: KadDHT's `get_value()` returns `None` for both an absent key and an inconclusive lookup, so it cannot prove absence for a conditional create. The method compares the hash with this `Libp2pKadDHT` instance's selected DHT/durable head under its local accepted-state lock, validates the finalized envelope with normal Registry transition rules, and checks `expires_at` immediately before beginning the DHT put. Current Identity reads use the same instance-local lock, so they cannot persist a locally cached candidate before the corresponding put call finishes. Identity validation also compares against the durable accepted head when the DHT value store is empty, preventing an older legacy envelope from rolling back accepted state after restart. It writes to DHT before installing the new local accepted head, so a local-store failure after the DHT call is ambiguous and requires fresh read-back. These checks are per instance, not a cross-node compare-and-swap; expiry is not carried in the DHT value and a request already sent may arrive after its deadline. Callers must treat ambiguous outcomes as unresolved.

The `/decent-registry` Kad-DHT namespace validator checks envelope structure and record-key binding, validates all Identity and versioned Provider transitions against locally retained accepted state, selects the highest sequence, and rejects equal-sequence competing states. Legacy Provider compatibility remains based on the current DHT value. For Identity, a durable accepted head remains authoritative after DHT cache loss, so replaying an older legacy envelope cannot roll it back. On a peer receiving a DHT PUT, Registry installs the validated envelope and predecessor history into its durable accepted store only after the local DHT value-store write succeeds; locally originated Registry publication retains its network-first ordering. A failure of durable installation after local DHT storage is ambiguous. Confirmation reads issue direct peer GET_VALUE requests and bypass `KadDHT.get_value()`; they return raw bytes without caching or entry repair, so the caller must validate the exact envelope and predecessor chain. Peers using a default/unupdated namespace validator may refuse to replace an existing value, so successful publication requires compatible Registry peers and must still be confirmed by a fresh read. A `DHTMode.SERVER` instance without a durable accepted-state store rejects post-genesis Identity writes before publication and rejects incoming post-genesis PUT values; a stateless `DHTMode.CLIENT` may submit an update using validated peer history but does not itself serve durable accepted history.

Operations 1–4 apply to Identity Records and Provider Records. Operation 5 is Identity-only. The record kind in authorization key `2` must match the SignedUpdate structure and the DHT namespace.
## 4. Local Multisignature Bundle workflow

A Multisignature Bundle is a local signing artifact. It contains one canonical SignedUpdate and zero or more detached proofs. Partial bundles are never valid Registry state and must never be submitted with `put`.

The workflow is:

1. `bundle draft` creates a canonical unsigned bundle.
2. Each signer runs `bundle sign` locally with one private-key path. The command emits a detached one-proof bundle and does not copy private-key material into the artifact.
3. `bundle merge` verifies the proof is bound to the exact SignedUpdate, belongs to the Signer Set, and has a valid Ed25519 signature. It rejects duplicate signers and mismatched bundles.
4. `bundle finalize` emits a finalized version-1 SignedEnvelope only when the required proof rule is met.
5. Only the finalized file is submitted with `put --finalized-envelope`.

`bundle sign` accepts only an unsigned bundle. To add another proof, sign the original unsigned bundle again and merge the detached proof into the accumulated bundle. Do not sign an already-signed bundle.

### 4.0 Local bundle example setup

The following setup creates real local inputs for the Bundle examples. It uses the installed `keygen` command for private keys and prints only the corresponding public keys. Private-key bytes are never printed or placed in the Bundle.

```bash
WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/decent-registry-multisig-example.XXXXXX")"
cd "$WORKDIR"

export OWNER_NAME_HEX="$(python3 -c 'print(b"cli-bundle-owner".hex())')"
export OBJECT_HASH="$(printf '%s' 'cli-provider-object' | sha256sum | cut -d' ' -f1)"
export PROVIDER_URL='https://example.com/artifact.bin'

for signer in alice bob carol dave; do
  decent-registry keygen --output "$WORKDIR/$signer.pem"
done

public_key_hex() {
  python3 - "$1" <<'PY'
import sys
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_pem_private_key,
)

with open(sys.argv[1], 'rb') as key_file:
    private_key = load_pem_private_key(key_file.read(), password=None)
print(private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex())
PY
}

export ALICE_PUBLIC_KEY_HEX="$(public_key_hex "$WORKDIR/alice.pem")"
export BOB_PUBLIC_KEY_HEX="$(public_key_hex "$WORKDIR/bob.pem")"
export CAROL_PUBLIC_KEY_HEX="$(public_key_hex "$WORKDIR/carol.pem")"
export DAVE_PUBLIC_KEY_HEX="$(public_key_hex "$WORKDIR/dave.pem")"
export OWNER_PUBLIC_KEY_HEX="$ALICE_PUBLIC_KEY_HEX"

signed_update_state_hash_hex() {
  python3 - "$1" <<'PY'
import cbor2
import hashlib
import sys

with open(sys.argv[1], 'rb') as envelope_file:
    envelope = cbor2.load(envelope_file)
if set(envelope) != {1, 2, 3} or not isinstance(envelope[2], bytes):
    raise SystemExit('expected a version-1 SignedEnvelope')
print(hashlib.sha256(envelope[2]).hexdigest())
PY
}
```

The example uses a single provider URI locator to construct and sign the v3 Provider Record; replace it with the actual object location before publication. The draft, sign, merge, finalize, incomplete-bundle, and replacement commands below are runnable after this setup. Network `put`/`get` commands additionally require a running Registry node and the `SEED_BOOTSTRAP` and `CLIENT_PORT` variables described in section 5.

### 4.1 Identity Record: genesis

Each `SIGNER_ID=PUBLIC_KEY_HEX` entry is a Signer Set member. The setup above uses Alice's public key as the Identity Record's Owner Public Key.

```bash
# Create the unsigned canonical bundle.
decent-registry bundle draft identity \
  --owner-name "$OWNER_NAME_HEX" \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 1 \
  --threshold 2 \
  --epoch 1 \
  --operation genesis \
  --signer "alice=$ALICE_PUBLIC_KEY_HEX" \
  --signer "bob=$BOB_PUBLIC_KEY_HEX" \
  --signer "carol=$CAROL_PUBLIC_KEY_HEX" \
  --output identity-genesis.draft.cbor

# Each signer uses a separate local private-key file.
decent-registry bundle sign \
  --input identity-genesis.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output identity-alice.proof.cbor

decent-registry bundle sign \
  --input identity-genesis.draft.cbor \
  --signer-privkey "$WORKDIR/bob.pem" \
  --output identity-bob.proof.cbor

# Merge detached proofs into a new local bundle.
decent-registry bundle merge \
  --input identity-genesis.draft.cbor \
  --proof identity-alice.proof.cbor \
  --proof identity-bob.proof.cbor \
  --output identity-genesis.partial-or-complete.cbor

# With two valid proofs in this 2-of-3 example, finalize the envelope.
decent-registry bundle finalize \
  --input identity-genesis.partial-or-complete.cbor \
  --output identity-genesis.signed-envelope.cbor
```

The private-key paths above are local inputs only. They are not embedded in the bundle, printed by the CLI, or sent to the Registry.

### 4.2 Provider Record: genesis

```bash
# Values and signer public keys come from section 4.0.
# Endpoint order in the input does not change the canonical payload; the
# provider schema stores endpoints in lexicographic order.
decent-registry bundle draft provider \
  --object-hash "$OBJECT_HASH" \
  --provider-url "$PROVIDER_URL" \
  --endpoint /ip4/127.0.0.1/tcp/10002 \
  --endpoint /ip4/127.0.0.1/tcp/10001 \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 1 \
  --threshold 2 \
  --epoch 1 \
  --operation genesis \
  --signer "alice=$ALICE_PUBLIC_KEY_HEX" \
  --signer "bob=$BOB_PUBLIC_KEY_HEX" \
  --signer "carol=$CAROL_PUBLIC_KEY_HEX" \
  --output provider-genesis.draft.cbor

decent-registry bundle sign \
  --input provider-genesis.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output provider-alice.proof.cbor

decent-registry bundle sign \
  --input provider-genesis.draft.cbor \
  --signer-privkey "$WORKDIR/bob.pem" \
  --output provider-bob.proof.cbor

decent-registry bundle merge \
  --input provider-genesis.draft.cbor \
  --proof provider-alice.proof.cbor \
  --proof provider-bob.proof.cbor \
  --output provider-genesis.complete.cbor

decent-registry bundle finalize \
  --input provider-genesis.complete.cbor \
  --output provider-genesis.signed-envelope.cbor
```

### 4.3 Incomplete bundles and rejection behavior

Finalization of a bundle with fewer than the required distinct proofs fails and does not publish output. The following commands are expected to exit non-zero for 2-of-3 bundles containing only one proof:

```bash
# Identity Record: identity-alice.proof.cbor was created in section 4.1.
decent-registry bundle finalize \
  --input identity-alice.proof.cbor \
  --output identity-should-not-be-published.cbor

# Provider Record: provider-alice.proof.cbor was created in section 4.2.
decent-registry bundle finalize \
  --input provider-alice.proof.cbor \
  --output provider-should-not-be-published.cbor
```

Neither output file is written on failure. The CLI also rejects:

- duplicate proof signers;
- proofs signed by a non-member of the Signer Set;
- proofs for a different SignedUpdate;
- malformed or invalid signatures;
- signing an already-signed bundle;
- finalized `put` combined with legacy signing arguments;
- finalized envelopes whose record kind or lookup key does not match the command.

### 4.4 Explicit legacy upgrade

Migration is explicit. It does not reinterpret a legacy SignedEnvelope as multisignature state.

1. Retain the original legacy SignedEnvelope file. `get` returns decoded record JSON, not the raw legacy envelope, so the application or publisher must preserve the file when the legacy record is created. For a fresh local Identity migration test, create a legacy envelope with the repository's canonical builder:

```bash
export LEGACY_IDENTITY_ENVELOPE="$WORKDIR/legacy-identity.signed-envelope.cbor"
python3 - "$LEGACY_IDENTITY_ENVELOPE" "$OWNER_NAME_HEX" "$WORKDIR/alice.pem" <<'PY'
import sys
from pathlib import Path
from decent_registry.envelope_builder import build_identity_envelope

output, owner_name_hex, private_key_path = sys.argv[1:]
Path(output).write_bytes(
    build_identity_envelope(
        owner_name_hex=owner_name_hex,
        owner_privkey_pem_path=private_key_path,
        seq=1,
    )
)
PY
```

   The legacy envelope must be submitted or already accepted for the same record key before the upgrade. Compute the predecessor hash from the canonical legacy SignedUpdate bytes inside that retained envelope:

```bash
export LEGACY_SIGNED_UPDATE_SHA256_HEX="$(python3 - "$LEGACY_IDENTITY_ENVELOPE" <<'PY'
import cbor2
import hashlib
import sys
from pathlib import Path

envelope = cbor2.loads(Path(sys.argv[1]).read_bytes())
if set(envelope) != {1, 2} or not isinstance(envelope[1], bytes):
    raise SystemExit('expected a legacy SignedEnvelope')
print(hashlib.sha256(envelope[1]).hexdigest())
PY
)"
```

   For a Provider Record migration, retain a Provider legacy envelope and compute its predecessor hash in the same way:

```bash
export LEGACY_PROVIDER_ENVELOPE="$WORKDIR/legacy-provider.signed-envelope.cbor"
python3 - "$LEGACY_PROVIDER_ENVELOPE" "$OBJECT_HASH" "$PROVIDER_URL" "$WORKDIR/alice.pem" <<'PY'
import sys
from pathlib import Path
from decent_registry.envelope_builder import build_provider_envelope

output, object_hash, provider_url, private_key_path = sys.argv[1:]
Path(output).write_bytes(
    build_provider_envelope(
        object_hash=object_hash,
        provider_urls=[provider_url],
        owner_privkey_pem_path=private_key_path,
        seq=1,
        endpoints=['/ip4/127.0.0.1/tcp/10001'],
    )
)
PY

export LEGACY_PROVIDER_SIGNED_UPDATE_SHA256_HEX="$(python3 - "$LEGACY_PROVIDER_ENVELOPE" <<'PY'
import cbor2
import hashlib
import sys
from pathlib import Path

envelope = cbor2.loads(Path(sys.argv[1]).read_bytes())
if set(envelope) != {1, 2} or not isinstance(envelope[1], bytes):
    raise SystemExit('expected a legacy SignedEnvelope')
print(hashlib.sha256(envelope[1]).hexdigest())
PY
)"
```

   After setting `REGISTRY_HOST`, `CLIENT_PORT`, and `SEED_BOOTSTRAP` as shown in section 5, publish these retained legacy envelopes before creating their corresponding upgrades:

   ```bash
   decent-registry put identity \
     --host "$REGISTRY_HOST" \
     --port "$CLIENT_PORT" \
     --bootstrap "$SEED_BOOTSTRAP" \
     --owner-name "$OWNER_NAME_HEX" \
     --finalized-envelope "$LEGACY_IDENTITY_ENVELOPE"

   decent-registry put provider \
     --host "$REGISTRY_HOST" \
     --port "$CLIENT_PORT" \
     --bootstrap "$SEED_BOOTSTRAP" \
     --object-hash "$OBJECT_HASH" \
     --finalized-envelope "$LEGACY_PROVIDER_ENVELOPE"
   ```

2. Build an `upgrade` bundle with the same record identity and Owner Public Key, `Seq` greater than the legacy `Seq`, `epoch 1`, a complete new Signer Set, and `--predecessor-state-hash "$LEGACY_SIGNED_UPDATE_SHA256_HEX"`.
3. The legacy owner signs the upgrade bundle. `bundle finalize` requires exactly that one valid legacy-owner proof.
4. Submit the finalized envelope with `put --finalized-envelope` against the existing record key.

Identity upgrade draft shape:

```bash
decent-registry bundle draft identity \
  --owner-name "$OWNER_NAME_HEX" \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 2 \
  --threshold 2 \
  --epoch 1 \
  --predecessor-state-hash "$LEGACY_SIGNED_UPDATE_SHA256_HEX" \
  --operation upgrade \
  --signer "legacy-owner=$OWNER_PUBLIC_KEY_HEX" \
  --signer "new-signer=$BOB_PUBLIC_KEY_HEX" \
  --signer "third-signer=$CAROL_PUBLIC_KEY_HEX" \
  --output identity-upgrade.draft.cbor

decent-registry bundle sign \
  --input identity-upgrade.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output identity-upgrade.owner-proof.cbor

decent-registry bundle merge \
  --input identity-upgrade.draft.cbor \
  --proof identity-upgrade.owner-proof.cbor \
  --output identity-upgrade.complete.cbor

decent-registry bundle finalize \
  --input identity-upgrade.complete.cbor \
  --output identity-upgrade.signed-envelope.cbor
```

The same sequence applies to Provider Records, using `bundle draft provider` and preserving the legacy Provider Record's Owner Public Key and Object Hash. The complete Provider Record command sequence is:

```bash
decent-registry bundle draft provider \
  --object-hash "$OBJECT_HASH" \
  --provider-url "$PROVIDER_URL" \
  --endpoint /ip4/127.0.0.1/tcp/10001 \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 2 \
  --threshold 2 \
  --epoch 1 \
  --predecessor-state-hash "$LEGACY_PROVIDER_SIGNED_UPDATE_SHA256_HEX" \
  --operation upgrade \
  --signer "legacy-owner=$OWNER_PUBLIC_KEY_HEX" \
  --signer "new-signer=$BOB_PUBLIC_KEY_HEX" \
  --signer "third-signer=$CAROL_PUBLIC_KEY_HEX" \
  --output provider-upgrade.draft.cbor

decent-registry bundle sign \
  --input provider-upgrade.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output provider-upgrade.owner-proof.cbor

decent-registry bundle merge \
  --input provider-upgrade.draft.cbor \
  --proof provider-upgrade.owner-proof.cbor \
  --output provider-upgrade.complete.cbor

decent-registry bundle finalize \
  --input provider-upgrade.complete.cbor \
  --output provider-upgrade.signed-envelope.cbor
```

An upgrade with a wrong predecessor hash, changed Owner Binding, wrong record kind, non-owner proof, more than one proof, or a non-increasing `Seq` is rejected.

### 4.5 Signer replacement

Signer replacement uses the current Signer Set to authorize installation of a new Signer Set. The examples below assume the genesis envelopes from sections 4.1 and 4.2 were finalized and accepted for their record keys. Alice and Bob are proofs from the current `{alice, bob, carol}` set; the replacement set is `{alice, bob, dave}`.

Identity Record replacement:

```bash
export IDENTITY_GENESIS_STATE_HASH_HEX="$(signed_update_state_hash_hex identity-genesis.signed-envelope.cbor)"

decent-registry bundle draft identity \
  --owner-name "$OWNER_NAME_HEX" \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 2 \
  --threshold 2 \
  --epoch 2 \
  --predecessor-state-hash "$IDENTITY_GENESIS_STATE_HASH_HEX" \
  --operation replace-signers \
  --signer "alice=$ALICE_PUBLIC_KEY_HEX" \
  --signer "bob=$BOB_PUBLIC_KEY_HEX" \
  --signer "dave=$DAVE_PUBLIC_KEY_HEX" \
  --output identity-replacement.draft.cbor

# Alice and Bob are current-set signers authorizing the new set.
decent-registry bundle sign \
  --input identity-replacement.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output identity-replacement.alice.proof.cbor

decent-registry bundle sign \
  --input identity-replacement.draft.cbor \
  --signer-privkey "$WORKDIR/bob.pem" \
  --output identity-replacement.bob.proof.cbor

decent-registry bundle merge \
  --input identity-replacement.draft.cbor \
  --proof identity-replacement.alice.proof.cbor \
  --proof identity-replacement.bob.proof.cbor \
  --output identity-replacement.complete.cbor

decent-registry bundle finalize \
  --input identity-replacement.complete.cbor \
  --output identity-replacement.signed-envelope.cbor
```

Provider Record replacement:

```bash
export PROVIDER_GENESIS_STATE_HASH_HEX="$(signed_update_state_hash_hex provider-genesis.signed-envelope.cbor)"

decent-registry bundle draft provider \
  --object-hash "$OBJECT_HASH" \
  --provider-url "$PROVIDER_URL" \
  --endpoint /ip4/127.0.0.1/tcp/10001 \
  --owner-public-key "$OWNER_PUBLIC_KEY_HEX" \
  --seq 2 \
  --threshold 2 \
  --epoch 2 \
  --predecessor-state-hash "$PROVIDER_GENESIS_STATE_HASH_HEX" \
  --operation replace-signers \
  --signer "alice=$ALICE_PUBLIC_KEY_HEX" \
  --signer "bob=$BOB_PUBLIC_KEY_HEX" \
  --signer "dave=$DAVE_PUBLIC_KEY_HEX" \
  --output provider-replacement.draft.cbor

decent-registry bundle sign \
  --input provider-replacement.draft.cbor \
  --signer-privkey "$WORKDIR/alice.pem" \
  --output provider-replacement.alice.proof.cbor

decent-registry bundle sign \
  --input provider-replacement.draft.cbor \
  --signer-privkey "$WORKDIR/bob.pem" \
  --output provider-replacement.bob.proof.cbor

decent-registry bundle merge \
  --input provider-replacement.draft.cbor \
  --proof provider-replacement.alice.proof.cbor \
  --proof provider-replacement.bob.proof.cbor \
  --output provider-replacement.complete.cbor

decent-registry bundle finalize \
  --input provider-replacement.complete.cbor \
  --output provider-replacement.signed-envelope.cbor
```

Submit and resolve both replacement envelopes using the finalized `put`/`get` commands in section 5, replacing the genesis filenames with `identity-replacement.signed-envelope.cbor` and `provider-replacement.signed-envelope.cbor`. The Registry rejects a replacement signed only by Dave or by any signer outside the current set, even though Dave belongs to the new set.

## 5. Registry submission and resolution

The finalized envelope is the only bundle artifact accepted by `put`. Start a Registry node using the operator setup documentation, copy its emitted `[BOOTSTRAP]` multiaddr, and set the deployment variables before running these commands:

```bash
export REGISTRY_HOST='127.0.0.1'
export CLIENT_PORT='9101'
export SEED_BOOTSTRAP='/ip4/127.0.0.1/tcp/9000/p2p/REPLACE_WITH_EMITTED_PEER_ID'
```

Replace only the `REPLACE_WITH_EMITTED_PEER_ID` component with the peer ID printed by the node. The remaining commands contain no shell-redirection placeholders. The same variables apply to the replacement and upgrade `put` commands described in sections 4.4 and 4.5.

### 5.1 Finalized Identity Record submission

```bash
decent-registry put identity \
  --host "$REGISTRY_HOST" \
  --port "$CLIENT_PORT" \
  --bootstrap "$SEED_BOOTSTRAP" \
  --owner-name "$OWNER_NAME_HEX" \
  --finalized-envelope identity-genesis.signed-envelope.cbor
```

Do not include `--owner-privkey` or `--seq` in finalized mode. The SignedUpdate inside the finalized envelope supplies the sequence and authorization data.

Resolve it with:

```bash
decent-registry get identity \
  --host "$REGISTRY_HOST" \
  --port "$CLIENT_PORT" \
  --bootstrap "$SEED_BOOTSTRAP" \
  --owner-name "$OWNER_NAME_HEX"
```

A multisignature Identity Record includes `object_key`, `owner_name`, `owner_public_key`, `seq`, and an `authorization` object containing `version`, numeric `operation`, `epoch`, `threshold`, sorted `signer_set`, `predecessor_state_hash`, and `state_hash`.

### 5.2 Finalized Provider Record submission

```bash
decent-registry put provider \
  --host "$REGISTRY_HOST" \
  --port "$CLIENT_PORT" \
  --bootstrap "$SEED_BOOTSTRAP" \
  --object-hash "$OBJECT_HASH" \
  --finalized-envelope provider-genesis.signed-envelope.cbor
```

Do not include `--provider-url`, `--endpoint`, `--owner-privkey`, or `--seq` in finalized mode.

Resolve it with:

```bash
decent-registry get provider \
  --host "$REGISTRY_HOST" \
  --port "$CLIENT_PORT" \
  --bootstrap "$SEED_BOOTSTRAP" \
  --object-hash "$OBJECT_HASH"
```

A multisignature Provider Record includes `object_key`, `object_hash`, `alg`, active payload `version` (`3`), `provider_urls`, sorted `endpoints`, `seq`, and the same `authorization` object.

The existing network setup and endpoint rules are documented in [protocol concepts](protocol-concepts.md), [Identity Record put/get examples](identity-put-get-examples.md), and [Provider Record put/get examples](provider-put-get-examples.md).

## 6. Compatibility matrix

| Producer or consumer | Legacy SignedEnvelope | Version-1 multisignature SignedEnvelope | Notes |
| --- | --- | --- | --- |
| Legacy decoder | Reads | Rejects | It accepts only the `{1,2}` envelope and legacy SignedUpdate shape. |
| Versioned decoder | Separate legacy path | Reads | It requires envelope version `1`, keys `{1,2,3}`, canonical CBOR, and authorization key `4`. |
| Legacy `put` before upgrade | Accepted if signature, key, Owner Binding, and `Seq` rules pass | Not applicable | Legacy signing arguments produce a legacy envelope. |
| Finalized-envelope `put` | A finalized legacy envelope remains supported by the legacy path | Accepted after transition validation | Finalized mode cannot be mixed with legacy arguments. |
| Legacy `put` after multisignature upgrade | Rejected | Not applicable | A record key cannot silently downgrade after upgrade. |
| `get identity` / `get provider` | Returns legacy fields | Returns fields plus authorization metadata | Resolution validates the accepted envelope before returning JSON. |
| Partial Multisignature Bundle | Not Registry state | Not Registry state | Keep local; finalize before submission. |

This is compatibility at the record and CLI boundary, not a promise that an old client can understand authorization metadata. An old client must continue using the legacy envelope path and cannot create or update a multisignature state.

## 7. Security boundaries

- Private keys remain local or hardware-backed. The CLI accepts file paths and never places private-key bytes in a bundle or Registry value. Registry operation-5 code does not accept, store, log, or return wallet private-key material; it handles only public records, signatures, and public predecessor envelopes.
- Signers exchange detached proofs, not private keys.
- Every proof is bound to the exact canonical SignedUpdate bytes.
- `merge` verifies signer membership and the Ed25519 signature before adding a proof.
- `finalize` verifies the threshold rule or the explicit single-owner upgrade rule.
- The Registry accepts only finalized envelopes, never partial bundles.
- `Seq`, predecessor state, record kind, lookup key, epoch, Owner Binding, and Signer Set rules are validated at the Registry boundary.
- Valid signatures do not guarantee DHT availability, endpoint reachability, privacy, permanence, or resistance to deployment failure.
- Recovery, key compromise response, and governance are not supplied by the ordinary Signer Set rules.

## 8. Verification and source links

Run the full suite from the repository root:

```bash
.venv/bin/pytest -q
```

The CLI-specific evidence is in [`tests/test_cli_multisig.py`](../tests/test_cli_multisig.py). The protocol source of truth is [protocol concepts](protocol-concepts.md). The implementation entry points are:

- [`encoding.py`](../src/decent_registry/encoding.py) — canonical SignedUpdate and authorization encoding;
- [`signed_envelope.py`](../src/decent_registry/signed_envelope.py) — legacy and versioned SignedEnvelope codecs;
- [`verification.py`](../src/decent_registry/verification.py) — proof and transition validation;
- [`multisig_bundle.py`](../src/decent_registry/multisig_bundle.py) — local Bundle operations;
- [`record_validator.py`](../src/decent_registry/record_validator.py) — record-family and overwrite integration;
- [`registry_service.py`](../src/decent_registry/registry_service.py) and [`libp2p_dht.py`](../src/decent_registry/dht/libp2p_dht.py) — finalized put/get integration.

The root [README](../README.md) and [developer guide](developer-guide.md) provide entry points for installation, node setup, and the non-multisignature CLI basics.

## 9. Current versus future

Current multisignature behavior is a versioned explicit-Ed25519 Signer Set with threshold proofs and a local circulation workflow. It is not FROST, not a recovery service, not a deployment topology, and not a privacy layer. Future work may define those surfaces, but they must not be inferred from the implemented version-1 format.
